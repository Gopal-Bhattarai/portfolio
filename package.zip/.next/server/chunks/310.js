"use strict";
exports.id = 310;
exports.ids = [310];
exports.modules = {

/***/ 7946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ initMongoose)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

async function initMongoose() {
    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) === 1) {
        return mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.asPromise();
    }
    return await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);
}


/***/ }),

/***/ 921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const candidateSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    name: {
        type: String,
        required: true
    },
    profession: {
        type: String
    },
    email: {
        primary: {
            type: String
        },
        secondary: {
            type: String
        }
    },
    phone: {
        primary: {
            type: String
        },
        secondary: {
            type: String
        }
    },
    address: {
        street: {
            type: String
        },
        city: {
            type: String
        }
    },
    image: {
        type: String
    },
    description: {
        type: String
    },
    active: {
        type: Boolean,
        default: 1
    },
    sociallink: {
        facebook: {
            type: String
        },
        instagram: {
            type: String
        },
        linkedin: {
            type: String
        },
        twitter: {
            type: String
        },
        github: {
            type: String
        }
    },
    proficiency: {
        item1: {
            key: {
                type: String
            },
            value: {
                type: String
            }
        },
        item2: {
            key: {
                type: String
            },
            value: {
                type: String
            }
        },
        item3: {
            key: {
                type: String
            },
            value: {
                type: String
            }
        },
        item4: {
            key: {
                type: String
            },
            value: {
                type: String
            }
        }
    },
    skills: {
        type: Object
    },
    portfolio: {
        type: Object
    },
    clients: {
        type: Object
    },
    experiences: {
        type: Object
    }
}, {
    timestamps: true
});
const Candidate = mongoose__WEBPACK_IMPORTED_MODULE_0__.models?.Candidate || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("Candidate", candidateSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Candidate);


/***/ })

};
;