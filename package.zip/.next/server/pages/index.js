"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 4369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_HeadTag__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7913);
/* harmony import */ var _components_PortFolioSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6198);
/* harmony import */ var _components_HeroSection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7784);
/* harmony import */ var _components_WhoAmI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4595);
/* harmony import */ var _components_WhatIAmGoodAt__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8747);
/* harmony import */ var _components_MyClients__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1224);
/* harmony import */ var _components_WorkExperience__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3540);
/* harmony import */ var _components_Statistics__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(788);
/* harmony import */ var _components_BlogSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7791);
/* harmony import */ var _components_ContactFormSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1194);
/* harmony import */ var _components_JoinTheClubSection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2653);
/* harmony import */ var _components_FooterSection__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(66);
/* harmony import */ var _components_NavMenuLargeScreen__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1322);
/* harmony import */ var _components_NavMenuSmallScreen__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3417);
/* harmony import */ var _components_MyExClients__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5742);
/* harmony import */ var _components_Alert__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5973);

















function Home({ blogs , candidate  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_HeadTag__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Alert__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                id: "main",
                className: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_NavMenuLargeScreen__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_HeroSection__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WhoAmI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WhatIAmGoodAt__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PortFolioSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MyClients__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MyExClients__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WorkExperience__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Statistics__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContactFormSection__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                candidate: candidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-72 bg-cover bg-center bg-no-repeat sm:h-64 md:h-72 lg:h-96",
                                style: {
                                    backgroundImage: "url(/assets/img/map.png)"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_JoinTheClubSection__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                candidate: candidate
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FooterSection__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        candidate: candidate
                    })
                ]
            })
        ]
    });
}
async function getServerSideProps(context) {
    const defaultID = "63e1b4544efb35048d08d31e";
    const candidate = await fetch(`${process.env.HOST}/api/candidate/${defaultID}`);
    const result = await candidate.json();
    const response = await fetch(`${process.env.HOST}/api/blog?limit=3`);
    const blogs = await response.json();
    return {
        props: {
            candidate: result,
            blogs: blogs.blogs
        }
    };
}


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,916,935], () => (__webpack_exec__(4369)));
module.exports = __webpack_exports__;

})();