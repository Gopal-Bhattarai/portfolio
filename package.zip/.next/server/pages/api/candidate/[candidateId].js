"use strict";
(() => {
var exports = {};
exports.id = 826;
exports.ids = [826];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 4673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_connectdb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7946);
/* harmony import */ var _model_candidate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(921);


async function handler(req, res) {
    const { candidateId  } = req.query;
    try {
        await (0,_lib_connectdb__WEBPACK_IMPORTED_MODULE_0__/* .initMongoose */ .T)();
        const candidate = await _model_candidate__WEBPACK_IMPORTED_MODULE_1__/* ["default"].findOne */ .Z.findOne({
            _id: candidateId
        });
        res.status(200).json(candidate);
    } catch (error) {
        res.status(500).json(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [310], () => (__webpack_exec__(4673)));
module.exports = __webpack_exports__;

})();