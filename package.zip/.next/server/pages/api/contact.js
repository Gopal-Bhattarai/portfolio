"use strict";
(() => {
var exports = {};
exports.id = 91;
exports.ids = [91];
exports.modules = {

/***/ 2639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "@sendgrid/mail"
const mail_namespaceObject = require("@sendgrid/mail");
var mail_default = /*#__PURE__*/__webpack_require__.n(mail_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/contact.js

mail_default().setApiKey(process.env.SGMAIL_API);
async function handler(req, res) {
    const newEmail = req.body;
    console.log(newEmail);
    await mail_default().send({
        to: "contact@gopalbhattarai.com.np",
        from: "contact@gopalbhattarai.com.np",
        subject: newEmail.name,
        text: newEmail.email + "\n\n" + newEmail.message
    });
    res.status(200).json({
        "status": "Email sent successfully!"
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2639));
module.exports = __webpack_exports__;

})();