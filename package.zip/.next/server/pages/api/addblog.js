"use strict";
(() => {
var exports = {};
exports.id = 37;
exports.ids = [37];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 7946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ initMongoose)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

async function initMongoose() {
    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) === 1) {
        return mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.asPromise();
    }
    return await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI);
}


/***/ }),

/***/ 4115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const blogSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    title: {
        type: String,
        required: true
    },
    category: {
        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.ObjectId,
        ref: "category"
    },
    meta: {
        type: String
    },
    image: {
        type: String
    },
    description: {
        type: String
    },
    active: {
        type: Boolean,
        default: 1
    },
    rating: {
        type: Number
    },
    author: {
        type: mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema.Types.ObjectId,
        ref: "author"
    }
}, {
    timestamps: true
});
const Blog = mongoose__WEBPACK_IMPORTED_MODULE_0__.models?.Blog || (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.model)("Blog", blogSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blog);


/***/ }),

/***/ 319:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_connectdb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7946);
/* harmony import */ var _model_blog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4115);
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5616);
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1738);
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(multer__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_2__]);
next_connect__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const upload = multer__WEBPACK_IMPORTED_MODULE_3___default()({
    storage: multer__WEBPACK_IMPORTED_MODULE_3___default().diskStorage({
        destination: "./public/image",
        filename: function(req, file, cb) {
            const newFileName = Math.floor(new Date().getTime()) + file.originalname;
            req.newfilename = newFileName;
            cb(null, newFileName);
        }
    }),
    fileFilter: (req, file, cb)=>{
        if (file.originalname.match(/\.(JPG|JPEG|jpg|jpeg|PNG|png|gif|GIF|BMP|bmp)$/)) {
            cb(null, true);
        } else {
            cb(null, false);
            return cb(new Error("Only .png, .jpg .jpeg, .gif or bmp format allowed"));
        }
    }
});
const apiRoute = (0,next_connect__WEBPACK_IMPORTED_MODULE_2__["default"])({
    onError (error, req, res) {
        res.status(501).json({
            error: `Sorry something Happened! ${error.message}`
        });
    },
    onNoMatch (req, res) {
        res.status(405).json({
            error: `Method '${req.method}' Not Allowed`
        });
    }
});
apiRoute.use(upload.single("image"));
apiRoute.post(async (req, res)=>{
    const image = req.newfilename;
    await (0,_lib_connectdb__WEBPACK_IMPORTED_MODULE_0__/* .initMongoose */ .T)();
    const { title , meta , description  } = req.body;
    const newBlog = await _model_blog__WEBPACK_IMPORTED_MODULE_1__/* ["default"].create */ .Z.create({
        title,
        meta,
        description,
        image
    });
    res.status(201).json(newBlog);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiRoute);
const config = {
    api: {
        bodyParser: false
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(319));
module.exports = __webpack_exports__;

})();